import { GeneticProfileOverview } from "@/components/genetic-profile-overview"
import { AncestryMap } from "@/components/ancestry-map"
import { HealthRiskSummary } from "@/components/health-risk-summary"
import { TraitHighlights } from "@/components/trait-highlights"
import { RelativeFinder } from "@/components/relative-finder"
import { ReportSwitcher } from "@/components/report-switcher"

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold tracking-tight">Genetic Dashboard</h1>

      <ReportSwitcher />

      <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-1">
        <GeneticProfileOverview />
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-7">
        <div className="lg:col-span-4">
          <AncestryMap />
        </div>
        <div className="lg:col-span-3">
          <HealthRiskSummary />
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-7">
        <div className="lg:col-span-4">
          <TraitHighlights />
        </div>
        <div className="lg:col-span-3">
          <RelativeFinder />
        </div>
      </div>
    </div>
  )
}

