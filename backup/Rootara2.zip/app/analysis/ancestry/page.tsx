"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Download, Share2, Info } from "lucide-react"
import { AncestryMap } from "@/components/ancestry-map"
import { RelativeFinder } from "@/components/relative-finder"

export default function AncestryAnalysisPage() {
  const [timelineView, setTimelineView] = useState("recent")

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Ancestry Analysis</h1>
          <p className="text-muted-foreground">Explore your genetic ancestry and find DNA relatives</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Export Data
          </Button>
          <Button variant="outline">
            <Share2 className="mr-2 h-4 w-4" />
            Share Results
          </Button>
        </div>
      </div>

      <Tabs defaultValue="composition" className="space-y-4">
        <TabsList>
          <TabsTrigger value="composition">Ancestry Composition</TabsTrigger>
          <TabsTrigger value="timeline">Timeline</TabsTrigger>
          <TabsTrigger value="relatives">DNA Relatives</TabsTrigger>
          <TabsTrigger value="haplogroups">Haplogroups</TabsTrigger>
        </TabsList>

        <TabsContent value="composition" className="space-y-4">
          <div className="grid gap-6 md:grid-cols-3">
            <div className="md:col-span-2">
              <AncestryMap />
            </div>
            <div>
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Understanding Your Results</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">
                    Your ancestry composition estimates the proportion of your DNA that comes from each of 45+
                    populations worldwide.
                  </p>
                  <div className="flex items-start space-x-2">
                    <Info className="h-5 w-5 text-primary mt-0.5" />
                    <p className="text-sm">
                      The analysis is based on comparing your genome to reference populations from around the world.
                    </p>
                  </div>
                  <Button variant="outline" className="w-full">
                    Learn More About Methodology
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="timeline" className="space-y-4">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">Ancestry Timeline</h2>
            <div className="flex gap-2">
              <Button
                variant={timelineView === "recent" ? "default" : "outline"}
                size="sm"
                onClick={() => setTimelineView("recent")}
              >
                Recent Ancestry
              </Button>
              <Button
                variant={timelineView === "ancient" ? "default" : "outline"}
                size="sm"
                onClick={() => setTimelineView("ancient")}
              >
                Ancient Ancestry
              </Button>
            </div>
          </div>

          <Card>
            <CardContent className="pt-6">
              <div className="relative h-[400px] w-full bg-gray-100 dark:bg-gray-800 rounded-md overflow-hidden">
                <div className="absolute inset-0 flex items-center justify-center">
                  <p className="text-sm text-muted-foreground">Ancestry timeline visualization would appear here</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Timeline Interpretation</CardTitle>
              <CardDescription>How to understand your ancestry timeline</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                The ancestry timeline shows approximately when you may have had an ancestor who was 100% from a
                particular population. The farther back in time, the less certain the estimate.
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="relatives" className="space-y-4">
          <div className="grid gap-6 md:grid-cols-3">
            <div className="md:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>DNA Relatives Map</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="relative h-[400px] w-full bg-gray-100 dark:bg-gray-800 rounded-md overflow-hidden">
                    <div className="absolute inset-0 flex items-center justify-center">
                      <p className="text-sm text-muted-foreground">Global map of DNA relatives would appear here</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            <div>
              <RelativeFinder />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="haplogroups" className="space-y-4">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Maternal Haplogroup</CardTitle>
                <CardDescription>Your maternal lineage</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-4">
                  <div className="text-4xl font-bold text-primary mb-2">H1c3</div>
                  <p className="text-sm text-muted-foreground mb-4">
                    Your maternal haplogroup can reveal the path your maternal ancestors took out of Africa.
                  </p>
                  <Button variant="outline">Explore Maternal Lineage</Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Paternal Haplogroup</CardTitle>
                <CardDescription>Your paternal lineage</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-4">
                  <div className="text-4xl font-bold text-primary mb-2">R1b1b2</div>
                  <p className="text-sm text-muted-foreground mb-4">
                    Your paternal haplogroup reveals the migration path of your paternal ancestors.
                  </p>
                  <Button variant="outline">Explore Paternal Lineage</Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Haplogroup Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="relative h-[300px] w-full bg-gray-100 dark:bg-gray-800 rounded-md overflow-hidden">
                <div className="absolute inset-0 flex items-center justify-center">
                  <p className="text-sm text-muted-foreground">Haplogroup distribution map would appear here</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

