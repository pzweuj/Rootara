import "./globals.css"
import { Inter } from "next/font/google"
import { ThemeProvider } from "@/components/theme-provider"
import { Sidebar } from "@/components/sidebar"
import { TopNav } from "@/components/top-nav"
import { TooltipProvider } from "@/components/ui/tooltip"
import { SettingsProvider } from "@/contexts/settings-context"
import { SidebarProvider } from "@/components/sidebar-context"
import { LanguageProvider } from "@/contexts/language-context"
import { cn } from "@/lib/utils"
import type React from "react"

const inter = Inter({ subsets: ["latin"] })

// 移除这里的 MainContent 组件定义
// 将其移动到单独的客户端组件文件中

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
          <SettingsProvider>
            <LanguageProvider>
              <SidebarProvider>
                <TooltipProvider delayDuration={0}>
                  <div className="min-h-screen flex">
                    <Sidebar />
                    {/* 使用动态导入的客户端组件 */}
                    <MainContent>{children}</MainContent>
                  </div>
                </TooltipProvider>
              </SidebarProvider>
            </LanguageProvider>
          </SettingsProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}

// 移除重复的导入
// import './globals.css'

export const metadata = {
  generator: 'v0.dev'
};

// 使用动态导入客户端组件
import { MainContent } from "@/components/main-content"
