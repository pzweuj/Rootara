"use client"

import { createContext, useContext, useState, type ReactNode, useEffect } from "react"

type Language = "en" | "zh-CN"

interface LanguageContextType {
  language: Language
  setLanguage: (language: Language) => void
  t: (key: string) => string
}

const translations = {
  en: {
    dashboard: "Dashboard",
    myReports: "My Reports",
    analysisModules: "Analysis Modules",
    tools: "Tools",
    helpCenter: "Help Center",
    allReports: "All Reports",
    uploadNewReport: "Upload New Report",
    ancestryAnalysis: "Ancestry Analysis",
    healthRisks: "Health Risks",
    traitInterpretation: "Trait Interpretation",
    rawData: "Raw Data",
    dataSharingManagement: "Data Sharing Management",
    accountSettings: "Account Settings",
    language: "Language",
    english: "English",
    simplifiedChinese: "Simplified Chinese",
    logOut: "Log Out",
    profile: "Profile",
    dataSharing: "Data Sharing",
    home: "Home",
    geneticDashboard: "Genetic Dashboard",
    snpsAnalyzed: "SNPs Analyzed",
    ancestryComposition: "Ancestry Composition",
    analysisSummary: "Analysis Summary",
    ancestryRegions: "4 Ancestry Regions",
    healthMarkers: "35 Health Markers",
    traits: "Traits",
    lastUpdated: "Last updated",
    yourDnaIndicates: "Your DNA indicates ancestry from 4 major global regions",
    geneticVariants: "Genetic variants related to health conditions",
    physicalAndBehavioral: "Physical and behavioral genetic traits",
  },
  "zh-CN": {
    dashboard: "仪表盘",
    myReports: "我的报告",
    analysisModules: "分析模块",
    tools: "工具",
    helpCenter: "帮助中心",
    allReports: "所有报告",
    uploadNewReport: "上传新报告",
    ancestryAnalysis: "祖源分析",
    healthRisks: "健康风险",
    traitInterpretation: "特征解读",
    rawData: "原始数据",
    dataSharingManagement: "数据共享管理",
    accountSettings: "账户设置",
    language: "语言",
    english: "英文",
    simplifiedChinese: "简体中文",
    logOut: "退出登录",
    profile: "个人资料",
    dataSharing: "数据共享",
    home: "首页",
    geneticDashboard: "基因仪表盘",
    snpsAnalyzed: "个SNP已分析",
    ancestryComposition: "祖源构成",
    analysisSummary: "分析摘要",
    ancestryRegions: "4个祖源区域",
    healthMarkers: "35个健康标记",
    traits: "个特征",
    lastUpdated: "最近更新",
    yourDnaIndicates: "您的DNA显示来自4个主要全球区域的祖源",
    geneticVariants: "与健康状况相关的基因变异",
    physicalAndBehavioral: "身体和行为的基因特征",
  },
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (!context) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>("en")

  // Load language preference from localStorage on initial render
  useEffect(() => {
    const savedLanguage = localStorage.getItem("language") as Language
    if (savedLanguage && (savedLanguage === "en" || savedLanguage === "zh-CN")) {
      setLanguageState(savedLanguage)
    }
  }, [])

  const setLanguage = (newLanguage: Language) => {
    setLanguageState(newLanguage)
    localStorage.setItem("language", newLanguage)
  }

  const t = (key: string): string => {
    return (translations[language] as Record<string, string>)[key] || key
  }

  return <LanguageContext.Provider value={{ language, setLanguage, t }}>{children}</LanguageContext.Provider>
}

