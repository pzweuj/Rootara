"use client"

import { useSidebar } from "@/components/sidebar-context"
import { TopNav } from "@/components/top-nav"
import { cn } from "@/lib/utils"
import type React from "react"

export function MainContent({ children }: { children: React.ReactNode }) {
  const { isCollapsed } = useSidebar()

  return (
    <div
      className={cn(
        "flex-1 transition-all duration-300 ease-in-out",
        isCollapsed ? "ml-[72px]" : "ml-72",
        "lg:translate-x-0",
      )}
    >
      <TopNav />
      <div className="container mx-auto p-6 max-w-7xl">
        <main className="w-full">{children}</main>
      </div>
    </div>
  )
}