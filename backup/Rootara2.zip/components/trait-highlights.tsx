import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Eye, Coffee, Sun, Moon, Droplet } from "lucide-react"

const traits = [
  {
    id: 1,
    name: "Eye Color",
    result: "Brown",
    description: "You have genetic markers associated with brown eyes.",
    icon: Eye,
    confidence: "high",
  },
  {
    id: 2,
    name: "Caffeine Metabolism",
    result: "Slow Metabolizer",
    description: "You may be more sensitive to caffeine's effects.",
    icon: Coffee,
    confidence: "medium",
  },
  {
    id: 3,
    name: "Sleep Patterns",
    result: "Night Owl",
    description: "Your genetic profile suggests you may naturally prefer staying up late.",
    icon: Moon,
    confidence: "high",
  },
  {
    id: 4,
    name: "Lactose Tolerance",
    result: "Tolerant",
    description: "You likely maintain the ability to digest lactose into adulthood.",
    icon: Droplet,
    confidence: "high",
  },
  {
    id: 5,
    name: "Sun Sensitivity",
    result: "Moderate",
    description: "You have a moderate genetic predisposition to sunburn.",
    icon: Sun,
    confidence: "medium",
  },
]

export function TraitHighlights() {
  const getConfidenceBadge = (confidence) => {
    const styles = {
      high: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
      medium: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
      low: "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200",
    }
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${styles[confidence]}`}>
        {confidence.charAt(0).toUpperCase() + confidence.slice(1)} confidence
      </span>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-medium">Trait Highlights</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {traits.slice(0, 3).map((trait) => (
            <div key={trait.id} className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <trait.icon className="h-5 w-5 text-primary mr-2" />
                  <span className="font-medium">{trait.name}</span>
                </div>
                {getConfidenceBadge(trait.confidence)}
              </div>
              <div>
                <p className="text-sm font-semibold">{trait.result}</p>
                <p className="text-xs text-muted-foreground">{trait.description}</p>
              </div>
            </div>
          ))}
          <Button className="w-full" variant="outline">
            View All Traits
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

