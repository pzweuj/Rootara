import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Users, UserPlus } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

const relatives = [
  {
    id: 1,
    name: "Sarah Johnson",
    relationship: "2nd Cousin",
    sharedDNA: 3.2,
    segments: 15,
    avatar:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/375238645_11475210.jpg-lU8bOe6TLt5Rv51hgjg8NT8PsDBmvN.jpeg",
  },
  {
    id: 2,
    name: "Michael Chen",
    relationship: "3rd Cousin",
    sharedDNA: 0.8,
    segments: 6,
    avatar:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/375238208_11475222.jpg-poEIzVHAGiIfMFQ7EiF8PUG1u0Zkzz.jpeg",
  },
  {
    id: 3,
    name: "Emma Williams",
    relationship: "4th Cousin",
    sharedDNA: 0.3,
    segments: 3,
    avatar: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/dd.jpg-4MCwPC2Bec6Ume26Yo1kao3CnONxDg.jpeg",
  },
]

export function RelativeFinder() {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-lg font-medium">DNA Relatives</CardTitle>
        <Button variant="outline" size="sm" className="h-8 px-2 lg:px-3">
          <UserPlus className="h-4 w-4 lg:mr-2" />
          <span className="hidden lg:inline">Invite Relatives</span>
        </Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {relatives.map((relative) => (
            <div key={relative.id} className="flex items-center justify-between">
              <div className="flex items-center">
                <Avatar className="h-10 w-10 mr-3">
                  <AvatarImage src={relative.avatar} alt={relative.name} />
                  <AvatarFallback>{relative.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-sm font-medium">{relative.name}</p>
                  <p className="text-xs text-muted-foreground">{relative.relationship}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-medium">{relative.sharedDNA}%</p>
                <p className="text-xs text-muted-foreground">{relative.segments} segments</p>
              </div>
            </div>
          ))}
          <Button className="w-full" variant="outline">
            <Users className="mr-2 h-4 w-4" />
            View All Relatives
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

